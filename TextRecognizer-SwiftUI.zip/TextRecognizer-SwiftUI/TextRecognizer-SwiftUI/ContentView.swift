//
//  ContentView.swift
//  TextRecognizer-SwiftUI
//
//  Created by Pallavi Dash on 20/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import SwiftUI
import Vision
import VisionKit

struct ContentView : View {
    var body: some View {
        VStack {
            ZStack {
                Image("scan")
                Image("barcode")
            }
            Text("Scan Bill")
            .color(.blue)
            HStack {
                PresentationButton(destination: PickerView()) {
                    //Text("Scan Bill")
                    Image(systemName: "photo.fill").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                }
                .padding()
                .padding(.leading,12)
                .padding(.top,30)
                
                PresentationButton(destination: TestView()) {
                    //Text("Scan Bill")
                    Image(systemName: "camera").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                }
                    .padding()
                    .padding(.leading,12)
                    .padding(.top,30)
            }
        }
    }
}

struct PickerView: View {
    var body: some View {
        ChooseImagePickerController()
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif

//Struct to show the image picker controller
struct ChooseImagePickerController: UIViewControllerRepresentable {
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = context.coordinator
        return imagePickerController
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: ChooseImagePickerController
        
        init(_ imagePickerController: ChooseImagePickerController) {
            self.parent = imagePickerController
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            
            picker.dismiss(animated: true, completion: {})
            var processView = PresentEditView()
            processView.image = info[.originalImage] as? UIImage
            processView.processImage()
        }
        
    }
}

//Struct to process the scanned image and store the data retrieved.
struct PresentEditView: View {
    @Environment(\.isPresented) private var isPresented
    
    //Variable to store the text of the processed image
    var resultingText = ""
    
    var tempArray = [String]()
    
    var arrayOfAmounts = ["Total Amount", "Amount", "Total"]
    
    var nextIndex = 0
    
    var newString = ""
    
    //Variable to store the processed image
    var image: UIImage?
    
    // Dispatch queue to perform Vision requests.
    private let textRecognitionWorkQueue = DispatchQueue(label: "TextRecognitionQueue",
                                                         qos: .userInitiated, attributes: [], autoreleaseFrequency: .workItem)
    
    // Vision requests to be performed on each image processed.
    private var requests = [VNRequest]()
    
    var body: some View {
        Text("Hello")
    }
    
    //mutating function that processes the text retrieved.
    mutating func updateProcessedText() {
        
        var result = self
        
        let textRecognitionRequest = VNRecognizeTextRequest {(request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                print("The observations are of an unexpected type.")
                return
            }
            // Concatenate the recognised text from all the observations.
            let maximumCandidates = 1
            for observation in observations {
                guard let candidate = observation.topCandidates(maximumCandidates).first else { continue }
                do {
                    let detector = try NSDataDetector(types: NSTextCheckingAllTypes)
                    let range = NSRange(candidate.string.startIndex..<candidate.string.endIndex, in: candidate.string)
                    detector.enumerateMatches(in: candidate.string,
                                              options: [],
                                              range: range) { (match, flags, _) in
                                                guard let match = match else {
                                                    return
                                                }
                                                
                                                switch match.resultType {
                                                case .date:
                                                    result.resultingText += "Bill Date: \(candidate.string)" + "\n"
                                                case .phoneNumber:
                                                    result.resultingText += "Phone Number: \(candidate.string)" + "\n"
                                                case .address:
                                                    result.resultingText += "Address: \(candidate.string)" + "\n"
                                                default:
                                                    return
                                                }
                                                
                    }
                    
                    result.tempArray.append(candidate.string)
                } catch {
                    print("handle error")
                }
            }
            
            for (_, item) in result.arrayOfAmounts.enumerated() {
                
                for (indexOfTemp, itemOfTemp) in result.tempArray.enumerated() {
                    let newTempString = itemOfTemp.replacingOccurrences(of: ":", with: "").lowercased()
                    if newTempString == item.lowercased() {
                        result.nextIndex = indexOfTemp + 1
                    }
                }
            }
            result.resultingText += "Total amount: \(result.tempArray[result.nextIndex])"
        }
        // specify the recognition level
        textRecognitionRequest.recognitionLevel = .accurate
        result.requests = [textRecognitionRequest]
        self = result
    }
    
    /*
     Method name: processImage
     Description: This method handles the image request sent
     */
    mutating func processImage() {
        
        var result = self
        result.updateProcessedText()
        //Clears all present text
        resultingText = ""
        guard let image = image else { return }
        
        textRecognitionWorkQueue.async {
            if let cgImage = image.cgImage {
                let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try requestHandler.perform(result.requests)
                } catch {
                    print(error)
                }
            }
            
            result.resultingText += "\n\n"
            
            print(result.resultingText)
        }
        self = result
    }
}

struct TestView: View {
    var body: some View {
        NavigationView {
        Text("Value")
        }
    }
}
